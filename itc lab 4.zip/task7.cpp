#include<iostream>
using namespace std;
int main()
{
    int average1, average2, average3, average4, average5, average6;
    cout << "Enter the average of section A: " ;
    cin >> average1;
    cout << "Enter the average of section B: " ;
    cin >> average2;
    cout << "Enter the average of section C: ";
    cin >> average3;
    cout << "Enter the average of section D: " ;
    cin >> average4;
    cout << "Enter the average of section E: ";
    cin >> average5;
    cout << "Enter the average of section F: " ;
    cin >> average6;
    int max = average1;
    cout << "A got highest average" << endl;
    if (average2 > average1)
    {
        max = average2;
        cout << "B got highest average" << endl;
    }
    else if(average3 > average2)
    {
        max = average3;
        cout << "C got highest average" << endl;
    }
    else if(average4 > average3)
    {
        max = average4;
        cout << "D got maximum average"<< endl;
    }
    else if(average5 > average4)
    {
        max = average5;
        cout << "E got maximum average" << endl;
    }
    else if(average6 > average5)
    {
        max = average6;
        cout << "F got highest average" << endl;
    }
    return 0;
}