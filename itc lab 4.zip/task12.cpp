#include<iostream>
using namespace std;
int main()
{
    double height, weight, BMI;
    cout << "Enter the height: ";
    cin >> height;
    cout << "Enter the weight: ";
    cin >> weight;
    BMI = weight / (height * height);
    cout << "The BMI is: " << BMI << endl;
    if (BMI < 18.5)
    {
        cout << "You are underweight" << endl;
    }
    else if(BMI >=18.5 && BMI <= 24.9)
    {
        cout << "Your BMI is normal" << endl;
    }
    else if(BMI >= 25 && BMI <= 29.9)
    {
        cout << "You are overweight" << endl;
    }
    else if (BMI >= 30)
    {
        cout << "You are obese" << endl;
    }
    return 0;
}