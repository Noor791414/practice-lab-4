#include<iostream>
using namespace std;
int main()
{
    int num1, num2;
    char op;
    cout<< "Enter the first number: " << num1;
    cin >> num1;
    cout << "Enter the operator: " ;
    cin >> op;
    cout << "Enter the second  number: " << num2;
    cin >> num2;
    switch (op) 
    { 
        case'+' : 
        cout << "The sum is: " << num1 + num2 << endl;
        break;
        case'-' :
        cout << "The difference is: " <<  num1 - num2 << endl;
        break;
        case'*' :
        cout << "The product is: " << num1 * num2 << endl;
        break;
        case'/' :
        if (num2!=0)
        {
            cout << "The division is: " << num1 / num2 << endl;
        }
        else 
        {
            cout << "ERROR" << endl;
            break;
        }
            default:
            cout << "Invalid operator ended. " << endl;
    }
    return 0;
}