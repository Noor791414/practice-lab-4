#include<iostream>
using namespace std;
int main()
{
    int average1, average2, average3, average4, average5, average6;
    cout << "Enter the average of section A: " ;
    cin >> average1;
    cout << "Enter the average of section B: " ;
    cin >> average2;
    cout << "Enter the average of section C: ";
    cin >> average3;
    cout << "Enter the average of section D: " ;
    cin >> average4;
    cout << "Enter the average of section E: ";
    cin >> average5;
    cout << "Enter the average of section F: " ;
    cin >> average6;
    int max = average1;
    cout << "A got highest average" << endl;
    if (average2 > average1)
    {
        max = average2;
        cout << "B got highest average" << endl;
    }
   #include<iostream>
using namespace std;
int main()
{
    int a, b, c;
    cout << "Enter the value of a: ";
    cin >> a;
    cout << "Enter the value of b: ";
    cin >> b;
    cout << "Enter the value of c: ";
    cin >> c;
    int secondMax;
    if ((a>b && a<c) || (a<b && a>c))
    {
    secondMax=a;
    }
    else if((b>a && b<c) || (b<a && b>c))
   {
       secondMax=b;
   }
   else 
   {
       secondMax=c;
   }
   cout << "The second maximum is: " << secondMax << endl;
   return 0;
}