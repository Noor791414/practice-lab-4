#include<iostream>
using namespace std;
int main()
{
    float number;
    cout << "Enter the floating point number: ";
    cin >> number;
    int floorValue = floor(number);
    cout << "The floor value is: " << floorValue << endl;
    return 0;
}
    