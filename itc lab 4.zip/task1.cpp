#include<iostream>
using namespace std;
int main()
{
	double marks1, marks2, marks3;
	cout << "Enter the marks obtained in subject 1: ";
	cin >> marks1;
	cout << "Enter the marks obtained in subject 2: ";
	cin >> marks2;
	 cout << "Enter the marks obtained in subject 3: ";
	cin >> marks3;
	double average = (marks1 + marks2 + marks3) / 3;
	if (average > 80) {
		cout << "You're above standard" << endl;
		cout << "Admission granted" << endl;
	}
	return 0;
}