#include<iostream>
using namespace std;
int main()
{
	int num1, num2;
	cout << "Enter the number 1: ";
	cin >> num1;
	cout << "Enter the number 2: ";
	cin >> num2;
	if (num2 / num1 == 0)
	{
		cout << "The number is multiple" << endl;
	}
	else 
	{
		cout << "The nummber is not the multiple" << endl;
	}
	return 0;
}