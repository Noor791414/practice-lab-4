#include<iostream>
using namespace std;
int main()
{
    int numberOfChocolates;
    float weightPerChocolate, totalWeight;
    char choice;
    cout << "Enter the number of chocolates: " ;
    cin >> numberOfChocolates;
    cout << "Enter the weight of one chocolate in ounces: ";
    cin >> weightPerChocolate;
    cout << "Enter the unit of measurement (O for ounces, P for pounds, G for grams, K for kilograms): ";
    cin >> choice;
    totalWeight = numberOfChocolates * weightPerChocolate;
    if (choice == 'o')
    {
        cout << "The total weight of the chocolates is: " << totalWeight << endl;
    }
    else if(choice == 'p')
    {
        totalWeight = numberOfChocolates * weightPerChocolate / 16 ;
        cout << "The total weight of the chocolates is: " << totalWeight << endl;
    }
    else if (choice == 'g')
    {
        totalWeight = numberOfChocolates * weightPerChocolate * 28.349;
        cout << "The total weight of the chocolates is: " << totalWeight << endl;
    }
    else if (choice == 'k')
    {
        totalWeight = numberOfChocolates * weightPerChocolate * 28.349 / 1000 ;
        cout << "The total weight of the chocolates is: " << totalWeight << endl;
    }
    else
    {
        cout << "Invalid choice entered" << endl;
    }
    return 0;
}
        
        