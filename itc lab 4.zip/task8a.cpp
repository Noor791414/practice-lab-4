#include<iostream>
using namespace std;
int main()
{
    int s1_c1, s1_c2, s1_c3, s1_c4, s1_c5;
    int s2_c1, s2_c2, s2_c3, s2_c4, s2_c5;
    int s3_c1, s3_c2, s3_c3, s3_c4, s3_c5;
    int s4_c1, s4_c2, s4_c3, s4_c4, s4_c5;
    int s5_c1, s5_c2, s5_c3, s5_c4, s5_c5;
    cout << "Enter marks of five courses of student 1: ";
    cin >>  s1_c1 >> s2_c2 >> s3_c3 >> s4_c4 >> s5_c5;
    int total1 = s1_c1 + s2_c2 + s3_c3 + s4_c4 + s5_c5;
    cout <<"Enter marks of five courses of student 2: ";
    cin >> s2_c1 >> s2_c2 >> s2_c3 >> s2_c4 >> s2_c5;
    int total2 = s2_c1 + s2_c2 + s2_c3 + s2_c4 + s2_c5;
    cout << "Enter the marks of five courses of student 3: ";
    cin >> s3_c1 >> s3_c2 >> s3_c3 >> s3_c4 >> s3_c5;
    int total3 = s3_c1 + s3_c2 + s3_c3 + s3_c4 + s3_c5;
    cout << "Enter the marks of five courses of student 4: ";
    cin >> s4_c1 >> s4_c2 >> s4_c3 >> s4_c4 >> s4_c5;
    int total4 =  s4_c1 + s4_c2 + s4_c3 + s4_c4 + s4_c5;
    cout << "Enter the marks of five courses of student 5: ";
    cin >> s5_c1 >> s5_c2 >> s5_c3 >> s5_c4 >> s5_c5;
    int total5 = s5_c1 + s5_c2 + s5_c3 + s5_c4 + s5_c5;
    int max;
    max = total1;
    if (total2 > total1)
    {
        max = total2;
        cout << "Highest aggregate is: " << total2;
    }
    else if(total3 > total2)
    {
        max = total3;
        cout << "Highest aggregate is: " << total3;
    }
    else if (total4 > total3)
    {
        max = total4;
        cout << "Highest aggregate is: " << total4;
    }
    else if (total5 > total4)
    {
        max = total5;
        cout << "Highest aggregate is: " << total5;
    }
    return 0;
}