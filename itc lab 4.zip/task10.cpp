  #include<iostream>
using namespace std;
int main()
{
    float number;
    cout << "Enter the floating point number: ";
    cin >> number;
    int ceilingValue = ceil(number);
    cout << "The ceiling value is: " << ceilingValue << endl;
    return 0;
}
    