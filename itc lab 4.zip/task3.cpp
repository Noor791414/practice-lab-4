#include<iostream>
using namespace std;
int main()
{
	int num1, num2, num3;
	cout << "Enter the first number: ";
	cin >> num1;
	cout << "Enter the second number: ";
	cin >> num2;
	cout << "Enter the third number: ";
	cin >> num3;
	int max = num1;
	if (num2 > num1)
		max = num2;
	else if (num3 > num2)
		max = num3;
	cout << "The maximum number is: " << max << endl;
	return 0;
}